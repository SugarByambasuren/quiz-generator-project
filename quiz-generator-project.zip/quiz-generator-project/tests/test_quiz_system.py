import unittest
from src.quiz_system import QuestionBank, StrictScoring, LenientScoring


class TestQuestionBank(unittest.TestCase):

    def test_load_questions(self):
        bank = QuestionBank()
        self.assertGreaterEqual(len(bank.questions), 1)

    def test_random_selection_no_repetition(self):
        bank = QuestionBank()
        questions = bank.get_random_questions(2)
        self.assertEqual(len(questions), len(set(questions)))


class TestScoringStrategies(unittest.TestCase):

    def test_strict_scoring(self):
        s = StrictScoring()
        self.assertEqual(s.score(True), 1.0)
        self.assertEqual(s.score(False), 0.0)

    def test_lenient_scoring(self):
        s = LenientScoring()
        self.assertEqual(s.score(True), 1.0)
        self.assertEqual(s.score(False), 0.5)


if __name__ == "__main__":
    unittest.main()
