# Quiz Generator System

## Overview

The **Quiz Generator System** is a command-line Python application that creates randomized quizzes from a JSON-based question bank. It demonstrates:

- Object-Oriented Programming (OOP)
- The **Factory** design pattern (for creating different types of questions)
- The **Strategy** design pattern (for swappable scoring rules)
- Basic testing with Python’s `unittest` framework

The system allows a user to take a quiz in either **Strict** or **Lenient** scoring mode.

---

## Project Structure

```text
quiz-generator-project/
├── main.py              # Entry point of the application
├── README.md            # Project overview and usage instructions
├── DESIGN.md            # Detailed architecture and design explanation
│
├── src/
│   ├── __init__.py      # Makes src a package
│   └── quiz_system.py   # Core implementation (classes, patterns, quiz logic)
│
├── tests/
│   └── test_quiz_system.py  # Unit tests for QuestionBank and scoring
│
├── data/
│   └── questions.json   # JSON question bank (MCQ and True/False)
│
└── docs/
    └── (optional diagrams or extra documentation)
