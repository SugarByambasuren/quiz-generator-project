import json
import os
import random
from abc import ABC, abstractmethod


# ------------- Question Classes ------------- #

class Question(ABC):
    """Base class for all question types."""

    def __init__(self, question_text: str, answer: str):
        self.question_text = question_text
        self.answer = str(answer).strip()

    @abstractmethod
    def ask(self) -> str:
        """Display the question and return the user's answer."""
        pass

    def check_answer(self, user_answer: str) -> bool:
        return str(user_answer).strip().lower() == self.answer.lower()


class MultipleChoiceQuestion(Question):
    """Multiple choice question with options."""

    def __init__(self, question_text: str, options, answer: str):
        super().__init__(question_text, answer)
        self.options = options

    def ask(self) -> str:
        print("\n" + self.question_text)
        for idx, option in enumerate(self.options, start=1):
            print(f"{idx}. {option}")

        while True:
            user_input = input("Enter option number: ").strip()
            if not user_input.isdigit():
                print("Please enter a valid number.")
                continue

            choice = int(user_input)
            if 1 <= choice <= len(self.options):
                return self.options[choice - 1]
            else:
                print("Choice out of range. Try again.")


class TrueFalseQuestion(Question):
    """True/False question."""

    def ask(self) -> str:
        print("\n" + self.question_text)
        while True:
            user_input = input("Enter True or False: ").strip().lower()
            if user_input in ("true", "t"):
                return "True"
            elif user_input in ("false", "f"):
                return "False"
            else:
                print("Please type True or False.")


# ------------- Factory Pattern ------------- #

class QuestionFactory:
    """Factory for creating question objects from raw data."""

    @staticmethod
    def create_from_dict(data: dict) -> Question:
        q_type = data.get("type", "").lower()
        question_text = data.get("question", "")
        answer = data.get("answer")

        if q_type == "mcq":
            options = data.get("options", [])
            return MultipleChoiceQuestion(question_text, options, answer)
        elif q_type == "tf":
            return TrueFalseQuestion(question_text, answer)
        else:
            raise ValueError(f"Unknown question type: {q_type}")


# ------------- Strategy Pattern (Scoring) ------------- #

class ScoringStrategy(ABC):
    """Base scoring strategy."""

    @abstractmethod
    def score(self, is_correct: bool) -> float:
        pass


class StrictScoring(ScoringStrategy):
    """Strict grading: correct = 1 point, incorrect = 0."""

    def score(self, is_correct: bool) -> float:
        return 1.0 if is_correct else 0.0


class LenientScoring(ScoringStrategy):
    """Lenient grading: correct = 1 point, incorrect = 0.5."""

    def score(self, is_correct: bool) -> float:
        return 1.0 if is_correct else 0.5


# ------------- QuestionBank ------------- #

class QuestionBank:
    """Loads questions from the data/questions.json file."""

    def __init__(self, data_path: str | None = None):
        # project_root = folder above src (where main.py lives)
        src_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.dirname(src_dir)

        if data_path is None:
            data_path = os.path.join(project_root, "data", "questions.json")

        self.data_path = data_path
        self.questions: list[Question] = []
        self._load_questions()

    def _load_questions(self) -> None:
        print(f"[DEBUG] Loading questions from: {self.data_path}")
        try:
            with open(self.data_path, "r", encoding="utf-8") as f:
                raw = json.load(f)
            self.questions = [QuestionFactory.create_from_dict(q) for q in raw]
            print(f"[DEBUG] Loaded {len(self.questions)} questions.")
        except FileNotFoundError:
            print(f"[ERROR] Could not find questions.json at: {self.data_path}")
            self.questions = []
        except json.JSONDecodeError as e:
            print(f"[ERROR] JSON decode error in {self.data_path}: {e}")
            self.questions = []

    def get_random_questions(self, n: int) -> list[Question]:
        """Return n unique random questions from the bank."""
        if n > len(self.questions):
            raise ValueError("Not enough questions in the question bank.")
        selected = random.sample(self.questions, n)
        random.shuffle(selected)
        return selected


# ------------- Quiz Class ------------- #

class Quiz:
    """Runs a quiz session."""

    def __init__(self, bank: QuestionBank, scoring_strategy: ScoringStrategy, num_questions: int = 3):
        self.bank = bank
        self.scoring_strategy = scoring_strategy
        self.num_questions = num_questions
        self.score = 0.0

    def start(self) -> float:
        if not self.bank.questions:
            print("No questions found. Exiting quiz.")
            return 0.0

        try:
            questions = self.bank.get_random_questions(self.num_questions)
        except ValueError as e:
            print(e)
            return 0.0

        print("\n--- Quiz Started ---")
        for q in questions:
            user_answer = q.ask()
            correct = q.check_answer(user_answer)
            gained = self.scoring_strategy.score(correct)
            self.score += gained

            if correct:
                print("✅ Correct!")
            else:
                print(f"❌ Incorrect. Correct answer: {q.answer}")

        print(f"\nFinal Score: {self.score} / {self.num_questions}")
        print("--- Quiz Ended ---")

        return self.score


# ------------- User Interface ------------- #

class UserInterface:
    """Console menu for quiz system."""

    def __init__(self):
        self.bank = QuestionBank()

    def run(self):
        while True:
            print("\n=== Quiz Generator ===")
            print("1. Strict quiz")
            print("2. Lenient quiz")
            print("3. Exit")
            choice = input("Choose an option: ").strip()

            if choice == "1":
                Quiz(self.bank, StrictScoring(), 3).start()
            elif choice == "2":
                Quiz(self.bank, LenientScoring(), 3).start()
            elif choice == "3":
                print("Goodbye!")
                break
            else:
                print("Invalid choice, try again.")


def run_quiz():
    """Entry function used by main.py"""
    UserInterface().run()
