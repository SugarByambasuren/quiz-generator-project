from src.quiz_system import run_quiz


if __name__ == "__main__":
    run_quiz()
